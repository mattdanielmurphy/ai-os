---
name: agy
description: "Delegate to agy CLI and use agy's LiteLLM proxy as a Hermes custom provider. Print mode, interactive mode, quoting, path conventions, and provider routing."
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [macos]
metadata:
  hermes:
    tags: [Agy, Subagent, Orchestration, CLI, Delegation]
    related_skills: [claude-code, opencode, ai-os-auto-commit]
---

# Agy — Local Orchestrator Agent

[Agy](https://github.com/nousresearch/hermes) is Matt's primary worker-bee orchestration agent. It runs locally via LiteLLM proxy on `localhost:8082` (inside tmux session `litellm`). Use it for cheap delegation — research, investigation, one-shot tasks, anything you'd rather not eat tokens for in your main thread.

## When to Use

- **Research tasks** — "find out why X is happening", "check system state", "investigate error Y"
- **Cheap parallel work** — agy uses tiered LiteLLM workers (cheaper models)
- **Fire-and-forget investigations** — start a background agy task and get results back
- **Anything the user explicitly asks you to delegate to agy** — don't over-engineer it, just call it

## Prerequisites

- agy installed at `~/.local/bin/agy` (confirm with `which agy`)
- LiteLLM proxy running: `tmux has-session -t litellm 2>/dev/null` (agy connects automatically)
- AGENTS.md/CLAUDE.md in the cwd — agy loads these for project context

## Critical: Argument Order

**`-p` takes the NEXT ARGUMENT as the prompt text.** This is the #1 pitfall.

```
# WRONG — --dangerously-skip-permissions gets consumed as the prompt text
agy -p --dangerously-skip-permissions "do X"

# RIGHT — prompt text immediately after -p, flags after the prompt
agy -p "do X" --dangerously-skip-permissions
```

In the wrong order, agy reads `--dangerously-skip-permissions` as your prompt and responds about its permission configuration instead of doing the task.

## Print Mode (One-Shot Tasks)

Print mode runs a single prompt non-interactively, returns the result, and exits. No PTY needed. This is the default integration path:

```bash
agy -p "Your task description here" --dangerously-skip-permissions --print-timeout 5m
```

### When to use print mode:
- One-shot investigations and diagnostics
- Scripted automation
- Any task where you don't need multi-turn conversation

### Timeout notes:
- `--print-timeout` defaults to `5m0s` (5 minutes)
- Must use Go duration format: `5m`, `10m`, `30s` — bare numbers fail with `invalid value`
- Set a high timeout for complex investigations; the command returns instantly when done, timeout is only a cap

### Quoting Guide for Shell Invocation

| Prompt contains | Use | Example |
|---|---|---|
| Any text (short or long) | Single quotes (bash multiline) | `agy -p 'your whole prompt here'` — single quotes prevent ALL bash interpretation of backticks, $, and other special chars |
| Single quotes inside prompt | Double-quote the outer string | `agy -p "it's a permissions issue"` |

**Rule of thumb:** ALWAYS use a single-quoted string directly in the terminal command. Single quotes pass everything through verbatim — backticks, $ signs, newlines, all of it. If the prompt is very long, bash single-quoted strings can span multiple lines naturally.

**NEVER do any of these:**
- ❌ Write prompt to a file and read with `$(cat file)` — backticks and $ signs in the file get interpreted by bash
- ❌ Use Python subprocess wrappers — triggers permission prompts, wastes CPU and time
- ❌ Pipe stdin into agy (`cat prompt | agy -p`) — agy doesn't read stdin for the prompt
- ❌ Create temp scripts, heredocs, or intermediate layers

If the quoting is awkward, fix the quoting — don't escalate the infrastructure. The user notices and is frustrated by extra processes, permission dialogs, and fan noise from needless overhead.

**Long prompts:** Bash single-quoted strings span multiple lines naturally. This works fine:
```bash
agy -p 'First paragraph of instructions.

Second paragraph with more detail.

Third paragraph with even more context.
Final line.' --dangerously-skip-permissions --print-timeout 5m
```

## Interactive Mode (Multi-Turn)

Not typically needed for agy (it's a worker, not a conversational agent), but available if the task needs follow-up:

```bash
agy -i "initial prompt" --dangerously-skip-permissions
```

## Key Flags

| Flag | Effect |
|------|--------|
| `-p, --print` | Non-interactive one-shot mode (takes NEXT ARG as prompt text) |
| `-i, --prompt-interactive` | Start interactive session with initial prompt |
| `-c, --continue` | Resume the most recent conversation |
| `--dangerously-skip-permissions` | Auto-approve all tool permission requests without prompting |
| `--print-timeout <duration>` | Max wait in Go duration format (e.g., `5m`, `30s`) |
| `--model <name>` | Override model for the session |
| `--agent <name>` | Choose a specific agent profile |
| `--mode <mode>` | Set execution mode: `accept-edits`, `plan` |
| `--project <id>` | Project ID for session context |
| `--sandbox` | Run with terminal restrictions enabled |
| `--conversation <id>` | Resume a specific conversation by ID |

## Procedure

1. **Formulate a self-contained prompt** — agy knows nothing about your conversation history. Include all context: file paths, error messages, constraints, and what you've already confirmed/found.
2. **Call agy via a direct terminal command.** Single-quoted string. Full stop. No Python wrappers, no temp files, no intermediate layers, no heredocs. Just `agy -p 'prompt' --dangerously-skip-permissions --print-timeout 5m`.
3. **Wait for the result** — `--print-timeout` handles the wait. The response comes back in `stdout`.
4. **Report findings** — summarize what agy found or did.

## Verification

Smoke test that agy responds:
```bash
agy -p "hello world this is a test" --print-timeout 1m
```
Expected: a relevant reply (not about permissions configuration — if it responds about permissions, the argument order was wrong and `--dangerously-skip-permissions` was eaten as the prompt text).

## Pitfalls & Gotchas

1. **#1: `-p` eats the next argument as the prompt.** Flags placed right after `-p` (like `--dangerously-skip-permissions`) become prompt text instead of flags. Prompt text must come IMMEDIATELY after `-p`, then other flags follow.
2. **Never use Python wrappers, temp files, or heredocs.** Writing the prompt to a file and reading it back, or wrapping in Python subprocess, triggers permission prompts, spins up the CPU, wastes time, and frustrates the user. Single-quoted string in terminal. Full stop.
3. **Don't over-engineer.** The user's instruction was "just call agy the way I told you." A direct terminal command with a single-quoted prompt string is always the right answer. If the quoting is awkward, fix the quoting — don't add layers.
4. **Long prompts can timeout.** If agy doesn't respond within `--print-timeout`, it errors with `timeout waiting for response`. Increase the timeout or simplify the prompt.
5. **agy loads project context** (AGENTS.md, CLAUDE.md) from the cwd. If you want agy to follow your prompt exactly and not derail into project-specific knowledge, be explicit about what to ignore.
6. **No heredocs.** Do not use `cat << 'EOF'` in terminal to write files for agy — use write_file instead.
7. **agy is not conversational.** It's a worker. Use `-p` for one-shots. Don't try to have multi-turn conversations unless you need `-i`.

## Using LiteLLM as a Hermes Provider

agy's LiteLLM proxy (`localhost:8082`) is an OpenAI-compatible endpoint. Hermes can use it as a `custom` provider — Hermes builds the full system prompt (memory, skills, tool schemas) and sends API calls to LiteLLM, preserving the complete Hermes experience while changing only where inference lands.

### Configuration

```yaml
# ~/.hermes/config.yaml
model:
  default: "hy3-free"          # see references/litellm-routing.md for full model list
  provider: "custom"
  base_url: "http://localhost:8082/v1"
```

No `api_key` needed — Hermes trusts loopback URLs for custom providers (`_loopback_hostname` in `runtime_provider.py`).

### Free models (truly zero-cost)

Three models route through OpenRouter's free tier: `hy3-free` (Tencent 295B MoE, strong coding), `poolside-laguna-free` (terminal/SE optimized), `nemotron-ultra-free` (NVIDIA, 1M context).

### Quota Pitfall: Gemini models do NOT use Antigravity free quota

The `gemini-2.5-flash` and `gemini-2.5-pro` models in LiteLLM route through `gemini/gemini-2.5-*` — this hits Google's API directly using `GEMINI_API_KEY`. This is a **separate quota bucket** from the Antigravity consumer OAuth free tier (`~/.gemini/oauth_creds.json`). Do not assume free Antigravity quota applies to LiteLLM Gemini models.

Full routing table and comparison of approaches: `references/litellm-routing.md`.

## Rules for Hermes Agents

1. **Call agy directly in terminal** — `agy -p 'prompt' --dangerously-skip-permissions --print-timeout 5m`. Single-quoted string, multiline if needed. No Python wrappers, no temp files, no intermediate layers, ever.
2. **Prompt after `-p`, flags after prompt** — correct order is critical.
3. **Self-contained prompts** — include all context agy needs; it has no memory of your session.
4. **Set a generous timeout** — investigations can take several minutes.
5. **Report results** — summarize what agy found, don't just dump the raw output.
6. **Use single quotes always** — they prevent ALL bash interpretation of special characters. If you need a literal single quote in the prompt, use double quotes for the outer string. Never escalate to file-read or Python.