---
name: local-automation-server
description: Debug local-automation-server or Control Center.
---

# Local Automation Server & Control Center

## Overview
`local-automation-server` is a local HTTP automation service hosted at `http://127.0.0.1:3033`. It provides APIs for local command execution, archiving, thread saving, and userscript management for the embedded `Userscript Control Center` (`control-center.js`).

## Secret Key & Authentication
- API calls require the `X-Local-Automation-Key` header.
- The server stores its secret key on disk at `~/.config/local-automation-server/secret`.
- The userscript Control Center reads this key from Tampermonkey storage via `GM.getValue("uscc_secret_key", "default-secret")`.
- If authentication fails with `Invalid or missing secret key`, use the **🔑 Set Secret Key** button in Control Center to save the key from `~/.config/local-automation-server/secret`.

## Service Operations via `la` CLI
The server is managed by macOS launch agent `com.matt.agent.local-automation-server.plist`.

```bash
# Check status
la status local-automation-server

# View live tmux logs
la logs local-automation-server

# Restart server
la restart local-automation-server

# Attach directly to tmux session
tmux attach -t agent-local-automation-server
```

## Control Center Hotkey: Cmd+Opt+I

The Control Center uses `Cmd+Opt+I` to toggle. See `references/capture-phase-shortcut-intercept.md` for the capture-phase technique that intercepts this before Chrome's DevTools handler.
