# Userscript Control Center Authentication Workflow

When `control-center.js` reports:
```text
Error connecting to Control API:
Invalid or missing secret key

Ensure local-automation-server is running on 127.0.0.1:3033.
```

### Steps to resolve:
1. Verify `local-automation-server` is running:
   ```bash
   la status local-automation-server
   ```
2. Read secret key from disk:
   ```bash
   cat ~/.config/local-automation-server/secret
   ```
3. Open Control Center in browser (`Alt+Shift+U`).
4. Click **🔑 Set Secret Key** button and paste secret key.
5. Control Center will save the key to `GM.setValue("uscc_secret_key", ...)` and reload data from `127.0.0.1:3033`.
