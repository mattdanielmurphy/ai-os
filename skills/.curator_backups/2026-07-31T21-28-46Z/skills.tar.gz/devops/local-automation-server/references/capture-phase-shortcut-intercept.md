# Browser Shortcut Interception: Capture Phase Pattern

Used by the Control Center (`control-center.js`) to intercept `Cmd+Opt+I` before Chrome's DevTools handler.

## The Problem

`e.preventDefault()` on a `keydown` listener for `Cmd+Opt+I` (or other browser-level shortcuts) doesn't work — the browser still opens DevTools.

## Root Cause

Browser-level shortcuts (Chrome DevTools, etc.) are handled at the **browser chrome level**, not the page event flow. A regular `keydown` listener fires during the **bubbling phase** — by the time it runs, the browser has already decided to handle the shortcut.

## The Fix: Capture Phase

```javascript
window.addEventListener("keydown", (e) => {
    if (e.metaKey && e.altKey && e.key === "i") {
        e.preventDefault();
        // your handler...
    }
}, { capture: true });  // ← fires during capture phase, before browser handles the shortcut
```

## When to Use

- Any shortcut conflicting with browser-level DevTools keys:
  - `Cmd+Opt+I` — DevTools
  - `Cmd+Opt+J` — DevTools Console
  - `Cmd+Opt+C` — DevTools Elements
  - `Cmd+Opt+U` — View source
  - `F12` — DevTools (Win/Linux)
- Userscripts that override browser shortcuts
- Web apps needing custom keyboard combos

## Tri-State Cycle Pattern (from Control Center)

```javascript
let ccHotkeyState = "closed"; // "closed" | "open" | "toast"

window.addEventListener("keydown", (e) => {
    if (e.metaKey && e.altKey && (e.key === "i" || e.key === "I")) {
        if (ccHotkeyState === "closed" || ccHotkeyState === "toast") {
            e.preventDefault();       // block DevTools on first press
            openUI();
            ccHotkeyState = "open";
        } else if (ccHotkeyState === "open") {
            // DO NOT preventDefault — let DevTools open on second press
            closeUI();
            showToast();
            ccHotkeyState = "toast";
        }
    }
}, { capture: true });
```

## Pitfalls

- **Not a silver bullet**: macOS system-level shortcuts cannot be intercepted by JS.
- **Keep the filter tight**: Capture phase fires for every keydown — check `e.key`, `e.metaKey`, etc.
- **`e.stopPropagation()` not needed**: `preventDefault()` is sufficient in capture phase.
- **Userscript context**: Listener must go on `window`, not `document`, in Tampermonkey.