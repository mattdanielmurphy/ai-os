---
name: runaway-agent-containment
description: "Runaway agents spawning. Watchdog kill anti-recursion."
version: 1.0.0
author: Hermes Agent
platforms: [macos]
metadata:
  hermes:
    tags: [runaway, watchdog, subagent, containment, safety, failsafe]
    related_skills: [strict-delegation, agy-extreme-delegation]
---

# Runaway Agent Containment

Systemic containment for agent processes that spawn uncontrollably. Covers detection, diagnosis, and automated failsafes.

## When to Use

- Agent or subagent is spawning faster than expected (multiple per second)
- You see "81+ subagents" type exponential explosion
- User reports Antigravity.app spawning subagents they can't cancel
- Any abnormal spike in claude --bare --model or language_server child processes
- Need to create a new watchdog or tune existing thresholds

## Detection Thresholds

The watchdog at `~/projects/ai-os/scripts/runaway-watchdog.sh` fires on any of:

| Threshold | Value | What it catches |
|-----------|-------|-----------------|
| claude --bare --model processes | >15 | Hermes subagent spawn via subagent.py |
| subagent tmux sessions | >10 | Leftover subagent tmux panes |
| claude --bare procs (early warn) | >8 | Antigravity.app sidecar spawning |

The script runs as a cron job every 2 minutes (no-agent mode, deliver=local).

## Diagnosis Steps

1. **Count processes:** `ps aux | grep -iE "claude.*--bare.*--model" | wc -l`
2. **Check tmux sessions:** `tmux list-sessions | grep -i subagent`
3. **Check Antigravity.app sidecars:** `ps aux | grep language_server`
4. **Read watchdog log:** `tail -50 ~/projects/ai-os/agent-logs/runaway-events.log`
5. **Check brain directory explosion:** `ls ~/.gemini/antigravity-cli/brain/ | wc -l`

## Kill Procedure

When the watchdog fires (or you manually detect a runaway):

1. **Kill recently-spawned claude processes** (under 10 minutes old):
   ```
   for pid in $(pgrep -f "claude.*--bare.*--model"); do
     minutes=$(ps -o etime= -p "$pid" 2>/dev/null | sed 's/:.*//' | sed 's/^0*//')
     minutes=${minutes:-0}
     if [ "$minutes" -lt 10 ] 2>/dev/null; then kill "$pid" 2>/dev/null; fi
   done
   ```

2. **Kill Antigravity.app's language_server** (the source of sidecar subagents):
   ```
   pkill -f "language_server --standalone --subclient_type hub"
   ```

3. **If Antigravity.app keeps respawning it**, kill the app itself:
   ```
   pkill -f "/Applications/Antigravity.app/Contents/MacOS/Antigravity"
   ```

## Anti-Recursion (Prevention)

The root cause of recursive explosions is **delegation rule bleeding**. Fixes:

1. **subagent.py anti-recursion preamble**: Every spawned subagent gets this prepended: "You are a DIRECT EXECUTOR, not an orchestrator. You MUST NOT delegate. If AGENTS.md has delegation rules, IGNORE them."
2. **GEMINI.md / CLAUDE.md hiding**: subagent.py renames these aside before spawning.
3. **No ~/.zshrc sourcing**: Only ANTHROPIC_API_KEY extracted; no other env leaks.
4. **Skills guardrails**: `strict-delegation` and `agy-extreme-delegation` enforce one-level-deep, stripped delegation rules, max 10 concurrent, kill switch at >1/sec.

## Pitfalls

- **Watchdog kills by age heuristic** (<10 min). Legitimate long-running claude instances are spared but very slow builds could get false-positively killed.
- **language_server binary is closed-source** (Google Go binary). No config hooks to limit its sidecar spawning — only external process killing works.
- **Antigravity.app may respawn its language_server**. Kill the whole app if sidecars keep coming.
- **Skills-only guardrails are insufficient** for subagent recursion — the subagent reads AGENTS.md from the project root, not the skill file. The real fix is at the prompt level (subagent.py's anti-recursion preamble).