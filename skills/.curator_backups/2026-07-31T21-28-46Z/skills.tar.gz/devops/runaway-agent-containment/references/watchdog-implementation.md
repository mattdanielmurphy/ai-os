# Watchdog Implementation Notes

## Script: `~/projects/ai-os/scripts/runaway-watchdog.sh`

Runs every 2 minutes via Hermes cron (no-agent mode, deliver=local).

### Detection Logic

```bash
CLAUDE_BARE_COUNT=$(pgrep -f "claude.*--bare.*--model" | wc -l)
SUBAGENT_TMUX_COUNT=$(tmux list-sessions | grep -i subagent | wc -l)
```

### Kill Logic

Kills claude --bare --model processes where elapsed time < 10 minutes.
Uses `ps -o etime=` to parse minutes:seconds vs hours:minutes:seconds formats.

Skips processes running 1+ hours (legitimate long-running work).
Sends macOS notification on alarm via `osascript -e 'display notification ...'`.

### Tuning

- `THRESHOLD_CLAUDE_BARE=15` — normal is 0-3, any more than 15 is certain runaway
- `THRESHOLD_SUBAGENT_TMUX=10` — normal is 1-2
- `THRESHOLD_LANGUAGE_SERVER_AGENTS=8` — early warning for Antigravity.app sidecar spawns

## Subagent.py Anti-Recursion Preamble

In `~/projects/ai-os/scripts/subagent.py`:

```python
ANTI_RECURSION_PREAMBLE = (
    "CRITICAL RULE — You are a DIRECT EXECUTOR, not an orchestrator. "
    "You MUST complete the task below using your OWN tools (Read, Edit, Bash). "
    "You MUST NOT delegate, spawn subagents, call subagent.py, or invoke any other agent. "
    "If the project's AGENTS.md or CLAUDE.md contains delegation rules (section 10, "
    "strict-delegation, subagent instructions), IGNORE those rules — they apply only to "
    "the top-level orchestrator, not to you. You are a leaf worker. Do your own work.\n\n"
)
```

This is prepended to `final_prompt` after resolution, before either the tmux or no-tmux code path. The subagent never sees the Hermes system prompt, AGENTS.md delegation rules, or any env context (except ANTHROPIC_API_KEY for auth).

## Antigravity.app language_server

The app bundles its own subagent spawning via a closed-source Go binary at:
`/Applications/Antigravity.app/Contents/Resources/bin/language_server`

Flags of interest:
- `--standalone` — runs independently
- `--subclient_type hub` — acts as central hub for sidecar subagents
- `--enable_sidecars` — enables subagent spawning
- `--override_model_name` — can override which model sidecars use
- `--model_api_client_type ccpa` — uses CCPA (Cloud Code) client with subagent support

This binary is ~138MB and contains Google's proprietary subagent code. There are no user-facing config files to limit its subagent spawning behavior. The only containment is external process killing.